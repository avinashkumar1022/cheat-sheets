---
title: Cinema4d
category: Apps
---

    E R T   : Move/rotate/scale
    P       : snapping
