---
title: jQuery CDN
category: JavaScript libraries
tags: [Archived]
layout: 2017/sheet
---

### Google jQuery

```html
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
```
