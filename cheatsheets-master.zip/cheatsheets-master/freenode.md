---
title: Freenode
layout: 2017/sheet
tags: [WIP]
---

### IRC server

```
irc.freenode.net
```

### NickServ commands

```
/msg nickserv identify [nick] <password>
/msg nickserv info <nick>
```

### Add a nick

```
/nick newnick
/msg nickserv identify <oldnick> <password>
/msg nickserv group
```
