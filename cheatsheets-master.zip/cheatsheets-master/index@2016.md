---
full_title: "Devhints — for web development and more"
description: "TL;DR for developer documentation - a ridiculous collection of cheatsheets"
layout: home
type: home
og_type: website
---
