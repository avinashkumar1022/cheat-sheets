---
title: "Phoenix: Ecto models"
category: Hidden
redirect_to: /phoenix-ecto
deprecated: true
---
