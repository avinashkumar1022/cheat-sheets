window.Prism = require('prismjs')
