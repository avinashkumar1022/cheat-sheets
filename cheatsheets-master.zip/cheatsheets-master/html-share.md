---
title: Share links
layout: 2017/sheet
category: HTML
updated: 2017-09-04
---

## Share links
{: .-one-column}

Facebook:
{:.-setup}

```html
<a href='https://www.facebook.com/sharer/sharer.php?u=URL' target='share'>
```

Twitter:
{:.-setup}

```html
<a href='https://twitter.com/intent/tweet?text=DESCRIPTION+URL' target='share'>
```

Google Plus:
{:.-setup}

```html
<a href='https://plus.google.com/share?url=URL' target='share'>
```
