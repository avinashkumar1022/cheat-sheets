---
title: Man
category: CLI
layout: 2017/sheet
---

### Man paths

| `1` | General User Commands |
| `2` | System Calls |
| `3` | Library Routines |
| `4` | Special Files and Sockets |
| `5` | File formats and Conventions |
| `6` | Games and Fun Stuff |
| `7` | Miscellaneous Documentation |
| `8` | System Administration |
| `9` | Kernel and Programming Style |
| `n` | Tcl/Tk |
