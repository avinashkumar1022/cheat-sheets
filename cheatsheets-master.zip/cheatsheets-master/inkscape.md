---
title: Inkscape
category: Apps
layout: 2017/sheet
tags: [WIP]
---

### All

| `-` _/_ `=` | Zoom in/out
| `3` _/_ `4` | Zoom to selection / drawing
| `5` _/_ `6` | Zoom to page / page width
{: .-shortcuts}

### Select tool (F1)

| `[ ]` | Rotate
{: .-shortcuts}

### Edit path (F2)

| `Ctrl` | constraint
{: .-shortcuts}

### Dragging an anchor handle

| `Ctrl` | snap to 15 degrees
| `Alt` | ?
{: .-shortcuts}

### Bezier (Shift F6)
